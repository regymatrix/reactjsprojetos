import { useState } from 'react';
import './App.css';
import Button from './components/Button';
import Input from './components/Input';

function App() {

  const [dados, setDados] = useState("Aguardando dados...")
  const [cep, setCep] = useState("")
  const handBuscaCEP = () => {
  
    const url = `https://viacep.com.br/ws/${cep}/json/`;
    console.log("CEP: " + cep);
    
    fetch(url)
    .then(response=>{      
      return response.json();
    })
    .then(data =>{
      console.log(data);
      console.log("Localidade: "+data.localidade);
      setDados('Endereço:  '+ data.logradouro + "\n" +
                'Complemento:  '+ data.complemento + "\n" +
                'Cidade: ' + data.localidade + "\n  " +
                'UF' + data.uf 
              )
    }).catch((erro) => {
      setDados("CEP inválido..." +erro)
    });  

  }

  return (
    <div className="App">
      <div>
        <label>CEP</label>
        <Input onChange={(e)=>setCep(e.target.value)}/>
        <Button onClick={handBuscaCEP}/>
      </div>
      <div>
        <label>{dados}</label>
      </div>      
    </div>
  );
}

export default App;
